"""Structured execution logging."""
