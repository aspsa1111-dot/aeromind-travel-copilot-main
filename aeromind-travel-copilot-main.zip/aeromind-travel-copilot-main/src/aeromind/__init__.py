"""AeroMind Travel Copilot package."""
