"""Specialized AeroMind agents."""
