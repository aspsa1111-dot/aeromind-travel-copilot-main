"""LangGraph workflow assembly."""
